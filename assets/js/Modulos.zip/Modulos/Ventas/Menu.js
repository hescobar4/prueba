var validarStock = function () {
    var codProducto = $(this).data("cod");
    var cuerpoTabla = $("[name=cuerpoTablaEntradas]");
    var modelFila =
        '<tr>' +
        '<td><span class="icon icon-arrow-down text-success" title="Ingresar venta" style="text-decoration:none; cursor:pointer; font-size:15px;" name="ingresarCantidadModal" data-codentrada="{0}" data-stock="{1}" data-codproducto="{3}" data-cantidadsalida="{4}"></span></td>' +
        '                           <td>{1}</td>' +
        '                           <td>{2}</td>' +
        '                   </tr>';
    $.ajax({
        url: BASE_URL + "Inventario/Menu/cargarEntradasForVentas",
        type: 'POST',
        data: {
            codProducto: codProducto
        },
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                cuerpoTabla.empty();
                for (var i = 0; i < data.length; i++) {
                    cuerpoTabla.append(modelFila.format(
                        data[i]['INVDETCOD'],
                        data[i]['STOCK'],
                        data[i]['INVDETVALORUNI'],
                        data[i]['CODPRODUCTO'],
                        data[i]['INVDETCANTIDADSAL'],
                        i + 1
                    ));
                }
                cuerpoTabla.find("[name=ingresarCantidadModal]").on("click", modalIngresarCantidad);
            } else {
                cuerpoTabla.empty();
                notificar(false, 'No se encontró información de Entradas');
            }
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

var modalIngresarCantidad = function () {
    var codEntrada = $(this).data("codentrada");
    var stock = $(this).data("stock");
    var codProducto = $(this).data("codproducto");
    var cantidadSalida = $(this).data("cantidadsalida");
    $("[name=codEntradaIngresar]").val((codEntrada != "") ? codEntrada : "");
    $("[name=stockIngresar]").val((stock != "") ? stock : "");
    $("[name=codProductoIngresar]").val((codProducto != "") ? codProducto : "");
    $("[name=cantidadSalidaIngresar]").val((cantidadSalida != "") ? cantidadSalida : "");
    ejecutarModal("modalIngresarCantidad");
}

var eliminarProductoVendido = function () {
    var codDetalleVenta = $(this).data("coddetalleventa");
    var codEntrada = $(this).data("codentrada");
    var cantidadEliminada = $(this).data("cantdadeliminada");
    var codVenta = $("[name=textCodVenta]").val();
    bootbox.confirm({
        title: "Confirmaci&oacute;n del Sistema",
        message: "&iquest;Est&aacute; seguro que desea eliminar el registro?",
        buttons: {
            confirm: {
                label: "Si",
                className: "btn-success"
            },
            cancel: {
                label: "No",
                className: "btn-danger"
            }
        },
        callback: function (result) {
            if (result === true) {
                $.ajax({
                    url: BASE_URL + "Ventas/Menu/eliminarProductoVendido",
                    type: 'POST',
                    data: {
                        codEntrada: codEntrada,
                        codDetalleVenta: codDetalleVenta,
                        cantidadEliminada: cantidadEliminada,
                    },
                    dataType: 'JSON',
                    success: function (r) {
                        notificar(r.data.success, r.data.msg);
                        cargarVenta(codVenta);
                    }
                }).fail(function () {
                    notificar(false, 'Error al procesar, por favor intente nuevamente');
                }).always(function () {

                });
            };
        }
    });
}

var cargarVenta = function (codVenta) {
    var cuerpoTabla = $("[name=cuerpoTablaProductosVendidos]");
    var modelFila =
        '<tr>' +
        '<td><span class="icon icon-bin text-danger" title="Ingresar venta" style="text-decoration:none; cursor:pointer; font-size:15px;" name="eliminarProductoVendido" data-coddetalleventa="{0}" data-codentrada="{1}" data-cantdadeliminada="{2}"></span> <span class="icon icon-calculator text-success" title="Ingresar descuento" style="text-decoration:none; cursor:pointer; font-size:15px;" name="ingresarDescuento" data-coddetalleventa="{0}"></span></td>' +
        '                           <td>{4}</td>' +
        '                           <td>{5}</td>' +
        '                           <td>{6}</td>' +
        '                           <td>{9}</td>' +
        '                           <td>{2}</td>' +
        '                           <td>{3}</td>' +
        '                           <td>{8}</td>' +
        '                           <td>{7}</td>' +
        '                   </tr>';
    showLoading();
    $.ajax({
        url: BASE_URL + "Ventas/Menu/cargarVenta",
        type: 'POST',
        data: {
            codVenta: codVenta
        },
        dataType: 'JSON',
        success: function (r) {
            var cabecera = r.data.cabeceraVenta;
            var detalle = r.data.detalleVenta;
            if (cabecera.length > 0) {
                $("[name=textCodVenta]").val((cabecera[0]['VENCOD'] != "") ? cabecera[0]['VENCOD'] : "");
                $("[name=textFechaVenta]").val((cabecera[0]['VENFECHA'] != "") ? cabecera[0]['VENFECHA'] : "");
                $("[name=textReferenciaVenta]").val((cabecera[0]['VENREFERENCIA'] != "") ? cabecera[0]['VENREFERENCIA'] : "");
                $("[name=textNombreClienteVenta]").val((cabecera[0]['VENNOMBRECLI'] != "") ? cabecera[0]['VENNOMBRECLI'] : "");
                $("[name=textIdentificacionVenta]").val((cabecera[0]['VENIDENTIFICACIONCLI'] != "") ? cabecera[0]['VENIDENTIFICACIONCLI'] : "");
                $("[name=textDireccionVenta]").val((cabecera[0]['VENDIRECCION'] != "") ? cabecera[0]['VENDIRECCION'] : "");
                $("[name=textMailVenta]").val((cabecera[0]['VENMAIL'] != "") ? cabecera[0]['VENMAIL'] : "");
            }
            if (detalle.length > 0) {
                cuerpoTabla.empty();
                for (var i = 0; i < detalle.length; i++) {
                    cuerpoTabla.append(modelFila.format(
                        detalle[i]['VENDETCOD'],
                        detalle[i]['VENDETINVDETCOD'],
                        detalle[i]['VENDETCANTIDAD'],
                        detalle[i]['INVDETVALORUNI'],
                        detalle[i]['PROCODIGODET'],
                        detalle[i]['PRONOMBRE'],
                        detalle[i]['PRODETALLE'],
                        detalle[i]['VALORTOTAL'],
                        detalle[i]['VENDETVALORDESC'],
                        detalle[i]['LABDETALLE'],
                    ));
                }
                cuerpoTabla.find("[name=eliminarProductoVendido]").on("click", eliminarProductoVendido);
                cuerpoTabla.find("[name=ingresarDescuento]").on("click", modalIngresarDescuento);
                cuerpoTabla.append(
                    '<tr style="background:rgb(107, 189, 130, 1);" class="text-white">' +
                    '   <td></td>' +
                    '   <td></td>' +
                    '   <td></td>' +
                    '   <td></td>' +
                    '   <td></td>' +
                    '   <td></td>' +
                    '   <td></td>' +
                    '   <td>TOTAL VENTA</td>' +
                    '   <td>' + r.data.totalVenta + '</td>' +
                    '</tr>');
                $("[name=cuerpoTablaEntradas]").empty();
                hideLoading();
            } else {
                cuerpoTabla.empty();
                $("[name=cuerpoTablaEntradas]").empty();
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

var modalIngresarDescuento = function () {
    $("[name=codDetalleVenta]").val(($(this).data("coddetalleventa") != "") ? $(this).data("coddetalleventa") : "");
    ejecutarModal("modalIngresarDescuento");
}

var cargarVentasFechas = function (parametro) {
    /* 
    PARAMETRO 1= CON RANGO DE FECHAS
    PARAMETRO 2= CON FECHA AUTOMATICAS HOY
    */

    var cuerpoTabla = $("[name=cuerpoTablaVentas]");
    var modelFila =
        '<tr>' +
        '<td><span class="icon icon-eye text-success" title="Ver venta" style="text-decoration:none; cursor:pointer; font-size:15px;" name="verVenta" data-codventa="{0}" data-codestadopago="{9}"></span> <span class="icon icon-printer text-primary" title="Generar comprobante" style="text-decoration:none; cursor:pointer; font-size:15px;" name="generarPdf" data-codventa="{0}"></span></td>' +
        '                           <td>{8}</td>' +
        '                           <td>{1}</td>' +
        '                           <td>{2}</td>' +
        '                           <td>{3}</td>' +
        '                           <td>{4}</td>' +
        '                           <td>{10}</td>' +
        '                           <td>{11}</td>' +
        '                   </tr>';
    if (parametro == 1) {
        var validate = $("[name=formularioVentasFecha]").formValidation({
            returnData: true
        });
        if (validate.error === true) {
            notificar(false, validate.message);
        } else {
            showLoading("Cargando");
            $.ajax({
                url: BASE_URL + "Ventas/Menu/cargaVentasCabecera",
                type: 'POST',
                data: {
                    datos: validate.data
                },
                dataType: 'JSON',
                success: function (r) {
                    var data = r.data
                    if (data.length > 0) {
                        ocultarModal("modalVentasFecha");
                        cuerpoTabla.empty();
                        for (var i = 0; i < data.length; i++) {
                            cuerpoTabla.append(modelFila.format(
                                data[i]['VENCOD'],
                                data[i]['VENFECHA'],
                                data[i]['VENREFERENCIA'],
                                data[i]['VENNOMBRECLI'],
                                data[i]['VENIDENTIFICACIONCLI'],
                                data[i]['VENDIRECCION'],
                                data[i]['VENMAIL'],
                                data[i]['VENESTADO'],
                                i + 1,
                                data[i]['VENESTADOPAGOCOD'],
                                data[i]['VENESTADOPAGONOMBRE'],
                                data[i]['USUARIO'],
                            ));
                        }
                        cuerpoTabla.find("[name=verVenta]").on("click", verVenta);
                        cuerpoTabla.find("[name=generarPdf]").on("click", generarPdf);
                    } else {
                        cuerpoTabla.empty();
                        notificar(false, "No se encontró información de ventas.");
                    }
                    hideLoading();
                }
            }).fail(function () {
                notificar(false, 'Error al procesar, por favor intente nuevamente');
            }).always(function () {

            });
        }
    }
    if (parametro == 2) {
        showLoading("Cargando");
        $.ajax({
            url: BASE_URL + "Ventas/Menu/cargaVentasCabecera",
            type: 'POST',
            data: {
                datos: 2
            },
            dataType: 'JSON',
            success: function (r) {
                var data = r.data;
                if (data.length > 0) {
                    cuerpoTabla.empty();
                    for (var i = 0; i < data.length; i++) {
                        cuerpoTabla.append(modelFila.format(
                            data[i]['VENCOD'],
                            data[i]['VENFECHA'],
                            data[i]['VENREFERENCIA'],
                            data[i]['VENNOMBRECLI'],
                            data[i]['VENIDENTIFICACIONCLI'],
                            data[i]['VENDIRECCION'],
                            data[i]['VENMAIL'],
                            data[i]['VENESTADO'],
                            i + 1,
                            data[i]['VENESTADOPAGOCOD'],
                            data[i]['VENESTADOPAGONOMBRE'],
                            data[i]['USUARIO'],
                        ));
                    }
                    cuerpoTabla.find("[name=verVenta]").on("click", verVenta);
                    cuerpoTabla.find("[name=generarPdf]").on("click", generarPdf);
                } else {
                    cuerpoTabla.empty();
                    notificar(false, "No se encontró información de ventas.");
                }
                hideLoading();
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {

        });
    }
}

var generarPdf = function () {
    var codVenta = $(this).data("codventa");
    window.open(BASE_URL + 'Ventas/Menu/generarPdf?codVenta=' + codVenta, '_blank');
    return;
}

var verVenta = function () {
    cargarVenta($(this).data("codventa"));
    estadoPago($(this).data("codestadopago"));
    cargarLab();
    ejecutarModal('modalRegistrarVenta');
}

var estadoPago = function (codEstadoPago) {
    // 0 PENDIENTE / 1 PAGA 

    var compEstadoPago = $("[name=sEstadoPago]");
    var modelRegistrar =
        '<option selected="true" value="">Seleccione</option>' +
        '<option value="0">PENDIENTE</option>' +
        '<option value="1">PAGA</option>';

    var modelPendiente =
        '<option selected="true" value="0">PENDIENTE</option>' +
        '<option value="1">PAGA</option>';

    var modelPaga =
        '<option value="0">PENDIENTE</option>' +
        '<option selected="true" value="1">PAGA</option>';

    if (codEstadoPago != 'x') {
        if (parseInt(codEstadoPago) == 0) {
            compEstadoPago.empty();
            compEstadoPago.append(modelPendiente);
            return;
        }
        if (parseInt(codEstadoPago) == 1) {
            compEstadoPago.empty()
            compEstadoPago.append(modelPaga);
            return;
        }
    } else {
        compEstadoPago.empty()
        compEstadoPago.append(modelRegistrar);
        return;
    }
}

var cargarLab = function () {
    var modelFilaSeleccione = '<option selected="true">Seleccione</option>';
    var modelFilaSelect = '<option value="{0}">{1}</option>';
    var cuerpoSelect = $("[name=sLab]");
    $.ajax({
        url: BASE_URL + "Laboratorios/Menu/cargarLaboratorios",
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                cuerpoSelect.empty();
                cuerpoSelect.append(modelFilaSeleccione);
                for (var i = 0; i < data.length; i++) {
                    cuerpoSelect.append(modelFilaSelect.format(
                        data[i]['LABCOD'],
                        data[i]['LABDETALLE'],
                    ));
                }
            } else {
                cuerpoSelect.empty();
                cuerpoSelect.append(modelFilaSeleccione);
                notificar(false, 'No se encontró información de Laboratorios');
            }
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

var cargarProductos = function (labCod) {
    var cuerpoTabla = $("[name=cuerpoTablaProductos]");
    var modelFila =
        '<tr>' +
        '<td><span class="icon icon-arrow-right text-success" title="Validar Stock" style="text-decoration:none; cursor:pointer; font-size:15px;" name="validarStock" data-cod="{0}"></span></td>' +
        '                           <td>{1}</td>' +
        '                           <td>{2}</td>' +
        '                           <td>{3}</td>' +
        '                           <td>{4}</td>' +
        '                   </tr>';
    $.ajax({
        url: BASE_URL + "Productos/Menu/cargarProductos",
        type: 'POST',
        data: {
            labCod: labCod
        },
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                cuerpoTabla.empty();
                for (var i = 0; i < data.length; i++) {
                    cuerpoTabla.append(modelFila.format(
                        data[i]['PROCOD'],
                        data[i]['PROCODIGODET'],
                        data[i]['PRONOMBRE'],
                        data[i]['PRODETALLE'],
                        data[i]['LABDETALLE'],
                        i + 1
                    ));
                }
                cuerpoTabla.find("[name=validarStock]").on("click", validarStock);
            } else {
                cuerpoTabla.empty();
                notificar(false, 'No se encontró información de Productos');
            }
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

$(document).ready(function () {
    $("[name=btnIniciarVenta]").click(function () {
        bootbox.confirm({
            title: "Confirmaci&oacute;n del Sistema",
            message: "&iquest;Est&aacute; seguro que desea registrar una nueva factura?",
            buttons: {
                confirm: {
                    label: "Si",
                    className: "btn-success"
                },
                cancel: {
                    label: "No",
                    className: "btn-danger"
                }
            },
            callback: function (result) {
                if (result === true) {
                    showLoading();
                    $.ajax({
                        url: BASE_URL + "Ventas/Menu/registrarVenta",
                        dataType: 'JSON',
                        success: function (r) {
                            notificar(r.data.success, r.data.msg);
                            hideLoading();
                            cargarVenta(r.data.codVenta);
                        }
                    }).fail(function () {
                        notificar(false, 'Error al procesar, por favor intente nuevamente');
                    }).always(function () {

                    });
                };
            }
        });
    });

    $("[name=btnCargarProductos]").click(function () {
        cargarProductos(0);
    });

    $("[name=btnIngresarCantidad]").click(function () {
        var codVenta = $("[name=textCodVenta]").val();
        if (codVenta == "") {
            notificar(false, "No hay ninguna venta en proceso.");
            return;
        }
        var validate = $("[name=formularioAgregarCantidad]").formValidation({
            returnData: true
        });
        if (validate.error === true) {
            notificar(false, validate.message);
        } else {
            showLoading();
            $.ajax({
                url: BASE_URL + "Ventas/Menu/ingresarProductoVenta",
                type: 'POST',
                data: {
                    codVenta: codVenta,
                    datos: validate.data
                },
                dataType: 'JSON',
                success: function (r) {
                    var alerta = r.data.alerta;
                    if (r.data.success) {
                        ocultarModal("modalIngresarCantidad");
                        cargarVenta(r.data.codVenta);
                        $("[name=cuerpoTablaEntradas]").empty();
                    } else {
                        notificar(r.data.success, r.data.msg);
                        $("[name=cuerpoTablaEntradas]").empty();
                    }

                    if (alerta === undefined || alerta.success) {

                    } else {
                        notificar(alerta.success, alerta.msg);
                    }
                    hideLoading();
                }
            }).fail(function () {
                notificar(false, 'Error al procesar, por favor intente nuevamente');
            }).always(function () {

            });
        }
    });

    $("[name=btnIngresarDescuento]").click(function () {
        var validate = $("[name=formularioAgregarDescuento]").formValidation({
            returnData: true
        });
        if (validate.error === true) {
            notificar(false, validate.message);
        } else {
            var codVenta = $("[name=textCodVenta]").val();
            showLoading("Guardando venta");
            $.ajax({
                url: BASE_URL + "Ventas/Menu/ingresarDescuento",
                type: 'POST',
                data: {
                    datos: validate.data
                },
                dataType: 'JSON',
                success: function (r) {
                    notificar(r.data.success, r.data.msg);
                    cargarVenta(codVenta);
                    ocultarModal("modalIngresarDescuento");
                    hideLoading();
                }
            }).fail(function () {
                notificar(false, 'Error al procesar, por favor intente nuevamente');
            }).always(function () {

            });
        }
    });

    $("[name=btnGuardarVenta]").click(function () {
        var codVenta = $("[name=textCodVenta]").val();
        if (codVenta == "" || codVenta == null || codVenta == undefined) {
            notificar(false, 'No hay ninguna venta en proceso');
            return;
        }
        var validate = $("[name=formularioGuardarVenta]").formValidation({
            returnData: true
        });
        if (validate.error === true) {
            notificar(false, validate.message);
        } else {
            showLoading("Guardando venta");
            $.ajax({
                url: BASE_URL + "Ventas/Menu/guardarVenta",
                type: 'POST',
                data: {
                    datos: validate.data
                },
                dataType: 'JSON',
                success: function (r) {
                    notificar(r.data.success, r.data.msg);
                    $("[name=textCodVenta]").val("");
                    $("[name=textFechaVenta]").val("");
                    $("[name=textReferenciaVenta]").val("");
                    $("[name=textNombreClienteVenta]").val("");
                    $("[name=textIdentificacionVenta]").val("");
                    $("[name=textDireccionVenta]").val("");
                    $("[name=textMailVenta]").val("");
                    $("[name=cuerpoTablaProductosVendidos]").empty();
                    $("[name=cuerpoTablaEntradas]").empty();
                    $("[name=cuerpoTablaProductos]").empty();
                    $("[name=cuerpoTablaVentas]").empty();
                    estadoPago('x');
                    hideLoading();
                }
            }).fail(function () {
                notificar(false, 'Error al procesar, por favor intente nuevamente');
            }).always(function () {

            });
        }
    });

    $("[name=btnCargarVentasFecha]").click(function () {
        cargarVentasFechas(1);
    });

    $("[name=btnCancelarVenta]").click(function () {
        var codVenta = $("[name=textCodVenta]").val();
        if (codVenta == "" || codVenta == null || codVenta == undefined) {
            notificar(false, 'No hay ninguna venta en proceso');
            return;
        }
        showLoading("Cancelando venta");
        $.ajax({
            url: BASE_URL + "Ventas/Menu/cancelarVenta",
            type: 'POST',
            data: {
                codVenta: codVenta
            },
            dataType: 'JSON',
            success: function (r) {
                notificar(r.data.success, r.data.msg);
                $("[name=textCodVenta]").val("");
                $("[name=textFechaVenta]").val("");
                $("[name=textReferenciaVenta]").val("");
                $("[name=textNombreClienteVenta]").val("");
                $("[name=textIdentificacionVenta]").val("");
                $("[name=textDireccionVenta]").val("");
                $("[name=textMailVenta]").val("");
                $("[name=cuerpoTablaProductosVendidos]").empty();
                $("[name=cuerpoTablaEntradas]").empty();
                $("[name=cuerpoTablaProductos]").empty();
                $("[name=cuerpoTablaVentas]").empty();

                hideLoading();
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {

        });
    });

    $("[name=textCantidadVender]").keypress(function (e) {
        var keycode = (e.keyCode ? e.keyCode : e.which);
        if (keycode == '13') {
            $("[name=btnIngresarCantidad]").click();
            return false;
        }
    });

    $("[name=textValorDescuento]").keypress(function (e) {
        var keycode = (e.keyCode ? e.keyCode : e.which);
        if (keycode == '13') {
            $("[name=btnIngresarDescuento]").click();
            return false;
        }
    });

    $("[name=btnCargarVentasHoy]").click(function () {
        cargarVentasFechas(2);
    });

    $("[name=btnModalRegistrarVenta]").click(function () {
        cargarLab();
        estadoPago('x');
    });

    $("[name=sLab]").change(function () {
        var labCod = $("[name=sLab]").val();
        if (labCod == "") {
            labCod = 0;
        }
        cargarProductos(labCod);
    });
});