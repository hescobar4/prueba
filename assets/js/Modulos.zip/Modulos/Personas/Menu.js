var ingresarPersona = function () {
    var validate = $("[name = formularioAgregarPersona]").formValidation({
        returnData: true
    });
    if (validate.error === true) {
        notificar(false, validate.message);
    } else {
        showLoading();
        $.ajax({
            url: BASE_URL + "Personas/Menu/ingresarPersona",
            type: 'POST',
            data: {
                datos: validate.data
            },
            dataType: 'JSON',
            success: function (r) {
                notificar(r.data.success, r.data.msg);
                if (r.data.success) {
                    ocultarModal("modalAgregarPersona");
                }
                hideLoading();
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {

        });
    }
}

var actualizarPersona = function () {
    var validate = $("[name = formularioEditarPersona]").formValidation({
        returnData: true
    });
    if (validate.error === true) {
        notificar(false, validate.message);
    } else {
        showLoading();
        $.ajax({
            url: BASE_URL + "Personas/Menu/actualizarPersona",
            type: 'POST',
            data: {
                datos: validate.data
            },
            dataType: 'JSON',
            success: function (r) {
                notificar(r.data.success, r.data.msg);
                if (r.data.success) {
                    ocultarModal("modalEditarPersona");
                }
                cargarPersonas();
                hideLoading();
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {

        });
    }
}

var cargarPersonas = function () {
    var modelfilaPersona = '<tr>' +
        '<td><span class="icon icon-pencil2 text-success" title="Editar" style="text-decoration:none; cursor:pointer; font-size:15px;" name="editar" data-cod="{0}" data-nombres="{1}" data-apellidos="{2}" data-identificacion="{3}" data-codtipoide="{4}" data-tipoide="{5}" data-tipogenero="{6}" data-codgenero="{7}" data-fechanac="{8}" data-telefono="{9}" data-direccion="{10}" data-email="{11}" data-tipopersona="{12}" data-codtipopersona="{13}"></span> <span class="icon icon-switch text-danger" title="Habilitar o Inhabilitar" style="text-decoration:none; cursor:pointer; font-size:15px;" name="estadoPersona" data-cod="{0}"></span></td>' +
        '                           <td>{15}</td>' +
        '                           <td>{1}</td>' +
        '                           <td>{2}</td>' +
        '                           <td>{3}</td>' +
        '                           <td>{5}</td>' +
        '                           <td>{12}</td>' +
        '                           <td>{14}</td>' +
        '                   </tr>';
    var cuerpoTablaPersonas = $("[name=cuerpoTablaPersonas]");
    showLoading();
    $.ajax({
        url: BASE_URL + "Personas/Menu/cargarPersonas",
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                cuerpoTablaPersonas.empty();
                for (var i = 0; i < data.length; i++) {
                    cuerpoTablaPersonas.append(modelfilaPersona.format(
                        data[i]['COD'],
                        data[i]['NOMBRES'],
                        data[i]['APELLIDOS'],
                        data[i]['IDENTITICACION'],
                        data[i]['CODTIPOIDE'],
                        data[i]['TIPOIDE'],
                        data[i]['TIPOGENERO'],
                        data[i]['CODGENERO'],
                        data[i]['FECHANAC'],
                        data[i]['TELEFONO'],
                        data[i]['DIRECCION'],
                        data[i]['EMAIL'],
                        data[i]['TIPOPERSONA'],
                        data[i]['CODTIPOPERSONA'],
                        data[i]['ESTADO'],
                        i + 1
                    ));
                }
                cuerpoTablaPersonas.find("[name=estadoPersona]").on("click", estadoPersona);
                cuerpoTablaPersonas.find("[name=editar]").on("click", modalEditarPersona);
            } else {
                cuerpoTablaPersonas.empty();
                sinInformacion();
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
};

var modalEditarPersona = function () {
    $("[name=modalEditarPersona]").modal("show");
    $("[name=codPersona]").val($(this).data("cod"));
    $("[name=identificacionAntigua]").val($(this).data("identificacion"));
    $(".textformulario").val("");

    $("[name=textNombre]").val($(this).data("nombres"));
    $("[name=textApellido]").val($(this).data("apellidos"));
    $("[name=textIdentificacion]").val($(this).data("identificacion"));
    $("[name=textFechaNac]").val($(this).data("fechanac"));
    $("[name=textTelefono]").val($(this).data("telefono"));
    $("[name=textDireccion]").val($(this).data("direccion"));
    $("[name=textEmail]").val($(this).data("email"));
    var tipoPersonaCod = $(this).data("codtipopersona");
    var tipoPersonaDetalle = $(this).data("tipopersona");
    var tipoIdeCod = $(this).data("codtipoide");
    var tipoIdeDetalle = $(this).data("tipoide");
    var tipoGenCod = $(this).data("codgenero");
    var tipoGenDetalle = $(this).data("tipogenero");
    tipoPersonaDiferenteSelect(tipoPersonaCod, tipoPersonaDetalle, "textTipoPersonaEditar");
    tipoIdentificacionDiferenteSelect(tipoIdeCod, tipoIdeDetalle, "tipoIdentificacionEditar");
    tipoGeneroDiferenteSelect(tipoGenCod, tipoGenDetalle, "textSexoEditar");
}

var estadoPersona = function () {
    var cod = $(this).data("cod");
    showLoading();
    $.ajax({
        url: BASE_URL + "Personas/Menu/estadoPersona",
        type: 'POST',
        data: {
            cod: cod
        },
        dataType: 'JSON',
        success: function (r) {
            notificar(r.data.success, r.data.msg);
            cargarPersonas();
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

var tipoPersonaDiferenteSelect = function (tipoCod, tipoDetalle, nameSelect) {
    var modelFilaSelect = '<option value="{0}">{1}</option>';
    var select = $("[name=" + nameSelect + "]");
    showLoading();
    $.ajax({
        url: BASE_URL + "Personas/Menu/tipoPersonaDiferente",
        type: 'POST',
        data: {
            tipoCod: tipoCod
        },
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                select.empty();
                select.append('<option selected="true" value="' + tipoCod + '"+>' + tipoDetalle + '</option>');
                for (var i = 0; i < data.length; i++) {
                    select.append(modelFilaSelect.format(
                        data[i]['TIPPERCOD'],
                        data[i]['TIPPERDETALLE'],
                    ));
                }
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

var tipoIdentificacionDiferenteSelect = function (tipoCod, tipoDetalle, nameSelect) {
    var modelFilaSelect = '<option value="{0}">{1}</option>';
    var select = $("[name=" + nameSelect + "]");
    showLoading();
    $.ajax({
        url: BASE_URL + "Personas/Menu/tipoIdentificacionDiferente",
        type: 'POST',
        data: {
            tipoCod: tipoCod
        },
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                select.empty();
                select.append('<option selected="true" value="' + tipoCod + '"+>' + tipoDetalle + '</option>');
                for (var i = 0; i < data.length; i++) {
                    select.append(modelFilaSelect.format(
                        data[i]['TIPCOD'],
                        data[i]['TIPDETALLE'],
                    ));
                }
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

var tipoGeneroDiferenteSelect = function (tipoCod, tipoDetalle, nameSelect) {
    var modelFilaSelect = '<option value="{0}">{1}</option>';
    var select = $("[name=" + nameSelect + "]");
    showLoading();
    $.ajax({
        url: BASE_URL + "Personas/Menu/tipoGeneroDiferente",
        type: 'POST',
        data: {
            tipoCod: tipoCod
        },
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                select.empty();
                select.append('<option selected="true" value="' + tipoCod + '"+>' + tipoDetalle + '</option>');
                for (var i = 0; i < data.length; i++) {
                    select.append(modelFilaSelect.format(
                        data[i]['GENCOD'],
                        data[i]['GENDETALLE'],
                    ));
                }
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

var cargarTipoPersonaSelect = function (nameSelect) {
    var modelFilaSelect = '<option value="{0}">{1}</option>';
    var modelFilaSelecccione = '<option selected="true" value="">Seleccione</option>';
    var select = $("[name=" + nameSelect + "]");
    showLoading();
    $.ajax({
        url: BASE_URL + "Personas/Menu/tipoPersona",
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                select.empty();
                select.append(modelFilaSelecccione);
                for (var i = 0; i < data.length; i++) {
                    select.append(modelFilaSelect.format(
                        data[i]['TIPPERCOD'],
                        data[i]['TIPPERDETALLE'],
                    ));
                }
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}
//FUNCIONES DE CREDITOS
var agregarCredito = function () {
    var datosPersona = $("[name=textNombreIdePersona]").val();
    if (datosPersona == "" || datosPersona == null) {
        notificar(false, "Por favor Busque y seleccione una Persona");
        return;
    }
    var validate = $("[name = formularioAgregarCredito]").formValidation({
        returnData: true
    });
    if (validate.error === true) {
        notificar(false, validate.message);
    } else {
        showLoading();
        $.ajax({
            url: BASE_URL + "Personas/Creditos/agregarCredito",
            type: 'POST',
            data: {
                datos: validate.data,
                datosPersona: datosPersona
            },
            dataType: 'JSON',
            success: function (r) {
                notificar(r.data.success, r.data.msg);
                if (r.data.success) {
                    ocultarModal("modalAgregarCredito");
                    cargarCreditos();
                }
                hideLoading();
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {

        });
    }
}

var cargarCreditos = function () {
    var datosPersona = $("[name=textNombreIdePersona]").val();
    if (datosPersona == "" || datosPersona == null) {
        notificar(false, "Por favor Busque y seleccione una Persona");
        return;
    }
    var moldelFila = '<tr>' +
        '<td><span class="icon icon-bin text-danger" title="Eliminar" name="eliminarCredito" style="text-decoration:none; cursor:pointer; font-size:15px;" data-codcredito="{0}"></span> <span class="icon icon-eye text-primary" title="Ver informaci&oacute;n" name="informacionCredito" style="text-decoration:none; cursor:pointer; font-size:15px;" data-codcredito="{0}" data-detellecredito="{1}" data-fechinicio="{2}" data-fechafin="{3}" data-valor="{4}" data-estado="{5}" data-valortotal="{7}" data-interes="{8}" data-coutas="{9}" data-tipointeres="{10}" data-periodicidad="{11}"></span></td>' +
        '<td>{2}</td>' +
        '<td>{3}</td>' +
        '<td>{4}</td>' +
        '<td class="{6}">{5}</td>' +
        '</tr>';
    var cuerpoTabla = $("[name=cuerpoTablaCreditos]");
    showLoading();
    $.ajax({
        url: BASE_URL + "Personas/Creditos/cargarCreditos",
        type: 'POST',
        data: {
            datosPersona: datosPersona
        },
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                cuerpoTabla.empty();
                for (var i = 0; i < data.length; i++) {
                    (data[i]['CREESTADO'] == "PENDIENTE") ? background = "table-danger" : background = "table-success";
                    cuerpoTabla.append(moldelFila.format(
                        data[i]['CRECOD'],
                        data[i]['CREDETALLE'],
                        data[i]['CREFECHAINICIO'],
                        data[i]['CREFECHAFIN'],
                        data[i]['CREVALOR'],
                        data[i]['CREESTADO'],
                        background,
                        data[i]['CREVALORTOTAL'],
                        data[i]['CREINTERES'],
                        data[i]['CRECUOTAS'],
                        data[i]['CRETIPOINTERES'],
                        data[i]['CREPERIODICIDAD']
                    ))
                }
                cuerpoTabla.find("[name=informacionCredito]").on("click", modalInformacionCredito);
                cuerpoTabla.find("[name=eliminarCredito]").on("click", eliminarCredito);
            } else {
                cuerpoTabla.empty();
                sinInformacion();
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

var eliminarCredito = function () {
    var codCredito = $(this).data("codcredito");
    bootbox.confirm({
        title: "Confirmaci&oacute;n de Sistema",
        message: "&iquest;Est&aacute; seguro que desea eliminar el registro?",
        buttons: {
            confirm: {
                label: "Si",
                className: "btn-success"
            },
            cancel: {
                label: "No",
                className: "btn-danger"
            }
        },
        callback: function (result) {
            if (result === true) {
                showLoading("Cargando");
                $.ajax({
                    url: BASE_URL + "Personas/Creditos/eliminarCredito",
                    type: 'POST',
                    data: {
                        codCredito: codCredito
                    },
                    dataType: 'JSON',
                    success: function (r) {
                        notificar(r.data.success, r.data.msg);
                        if (r.data.success) {
                            cargarCreditos();
                        }
                        hideLoading();
                    }
                }).fail(function () {
                    hideLoading();
                    notificar(false, 'Error al procesar, por favor intente nuevamente');
                }).always(function () {

                });
            };
        }
    });
}

var editarCredito = function () {
    var validate = $("[name = formularioEditarCredito]").formValidation({
        returnData: true
    });
    if (validate.error === true) {
        notificar(false, validate.message);
    } else {
        showLoading();
        $.ajax({
            url: BASE_URL + "Personas/Creditos/editarCredito",
            type: 'POST',
            data: {
                datos: validate.data
            },
            dataType: 'JSON',
            success: function (r) {
                notificar(r.data.success, r.data.msg);
                if (r.data.success) {
                    ocultarModal("modalEditarCredito");
                    cargarCreditos();
                }
                hideLoading();
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {

        });
    }
}

var modalInformacionCredito = function () {
    $("[name=codCredito]").val($(this).data("codcredito"));
    $("[name=textFechaInicioCredito]").val($(this).data("fechinicio"));
    $("[name=textFechaFinCredito]").val($(this).data("fechafin"));
    $("[name=textValorCredito]").val($(this).data("valor"));
    $("[name=textObservacionCredito]").val($(this).data("detellecredito"));
    $("[name=textCoutas]").val($(this).data("coutas"));
    $("[name=textInteresInfo]").val($(this).data("interes"));
    $("[name=textTipoInteresInfo]").val($(this).data("tipointeres"));
    $("[name=textPeriodicidadInfo]").val($(this).data("periodicidad"));
    cargarAbonos($(this).data("codcredito"));
    ejecutarModal("modalInformacionCredito");
}

var cargarAbonos = function (codCredito) {
    var modelFila = '<tr>' +
        '<td><span class="icon icon-bin text-danger" title="Eliminar" name="eliminarAbono" style="text-decoration:none; cursor:pointer; font-size:15px;" data-codabono="{0}"</span></td>' +
        '<td>{1}</td>' +
        '<td>{6}</td>' +
        '<td>{2}</td>' +
        '<td>{3}</td>' +
        '<td>{4}</td>' +
        '<td>{5}</td>' +
        '</td>';
    var cuerpoTabla = $("[name=cuerpoTablaAbonosCredito]");
    showLoading();
    $.ajax({
        url: BASE_URL + "Personas/Creditos/cargarAbonos",
        type: 'POST',
        data: {
            codCredito: codCredito
        },
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                cuerpoTabla.empty();
                for (var i = 0; i < data.length; i++) {
                    cuerpoTabla.append(modelFila.format(
                        data[i]['ABOCOD'],
                        data[i]['ABOFECHA'],
                        data[i]['ABOCAPITAL'],
                        data[i]['ABOCUOTA'],
                        data[i]['ABOINTERES'],
                        data[i]['ABOSALDO'],
                        i
                    ));
                }
                cuerpoTabla.find("[name=eliminarAbono]").on("click", eliminarAbono);
            } else {
                cuerpoTabla.empty();
                sinInformacion();
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

var eliminarAbono = function () {
    var codAbono = $(this).data("codabono");
    var codCredito = $("[name=codCredito]").val();
    bootbox.confirm({
        title: "Confirmaci&oacute;n de Sistema",
        message: "&iquest;Est&aacute; seguro que desea eliminar el registro?",
        buttons: {
            confirm: {
                label: "Si",
                className: "btn-success"
            },
            cancel: {
                label: "No",
                className: "btn-danger"
            }
        },
        callback: function (result) {
            if (result === true) {
                showLoading("Cargando");
                $.ajax({
                    url: BASE_URL + "Personas/Creditos/eliminarAbono",
                    type: 'POST',
                    data: {
                        codAbono: codAbono,
                        codCredito: codCredito
                    },
                    dataType: 'JSON',
                    success: function (r) {
                        notificar(r.data.success, r.data.msg);
                        if (r.data.success) {
                            cargarAbonos(codCredito);
                            cargarCreditos();
                            ocultarModal("modalAgregarAbono");
                        }
                    }
                }).fail(function () {
                    hideLoading();
                    notificar(false, 'Error al procesar, por favor intente nuevamente');
                }).always(function () {

                });
            };
        }
    });

}

var agregarAbono = function () {
    var codCredito = $("[name=codCredito]").val();
    var abonoAuto = $("#abonoAutomatico").is(":checked");
    var informacion = new Array();

    if (!abonoAuto) {
        var validate = $("[name = formularioAgregarAbono]").formValidation({
            returnData: true
        });
        if (validate.error === true) {
            notificar(false, validate.message);
            return;
        } else {
            var informacion = validate.data;
        }
    } else {
        informacion = false;
    }
    showLoading();
    $.ajax({
        url: BASE_URL + "Personas/Creditos/agregarAbono",
        type: 'POST',
        data: {
            codCredito: codCredito,
            datos: informacion
        },
        dataType: 'JSON',
        success: function (r) {
            notificar(r.data.success, r.data.msg);
            if (r.data.success) {
                cargarCreditos();
                cargarAbonos(codCredito);
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}
//FUNCIONES DE CREDITOS


//FUNCION DE BUSCAR PERSONA
var encontrarPersona = function () {
    var modelFila = '<tr> ' +
        '               <td><center>' +
        '                   <input type="radio" name="radioPersona" data-identificacion="{0}" data-nombres="{1}" data-tipo="{2}" data-cod="{3}"/>' +
        '                   </center></td>' +
        '               <td>{1}</td>' +
        '               <td>{0}</td>' +
        '               <td>{2}</td>' +
        '           </tr>';
    var parametros = $("[name=textParametrosPersona]").val();
    var cuerpoTabla = $("[name=cuerpoTalblaEncontrarPersonas]");
    if (parametros == "" || parametros == null) {
        notificar(false, "Por favor, digite Nombres, Apellidos o Identificación de la Persona");
        return;
    }
    showLoading();
    $.ajax({
        url: BASE_URL + "Personas/Menu/encontrarPersona",
        type: 'POST',
        data: {
            parametros: parametros
        },
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                cuerpoTabla.empty();
                for (var i = 0; i < data.length; i++) {
                    cuerpoTabla.append(modelFila.format(
                        data[i]['IDENTIFICACION'],
                        data[i]['NOMBRES'],
                        data[i]['TIPOPERSONA'],
                        data[i]['PERCOD'],
                    ));
                }
            } else {
                sinInformacion();
                cuerpoTabla.empty();
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {

    });
}

var seleccionarPersona = function () {
    var radioSeleccionado = $('[name=cuerpoTalblaEncontrarPersonas] [name=radioPersona]:checked');
    if (radioSeleccionado.val() == "" || radioSeleccionado.val() == null) {
        notificar(false, "Por favor, seleccione una Persona");
        return;
    }
    var identificacion = radioSeleccionado.data('identificacion');
    var nombres = radioSeleccionado.data('nombres');
    var cod = radioSeleccionado.data('cod');
    $("[name=textNombreIdePersona]").val(identificacion + " - " + nombres);
    ocultarModal("modalEncontrarPersona");
}
//FUNCION DE BUSCAR PERSONA


$(document).ready(function () {
    $("[name = btnGuardarPersona]").click(function () {
        ingresarPersona();
    });

    $("[name = cargarPersonas]").click(function () {
        cargarPersonas();
    });

    $("[name = btnModalAgregarPersona]").click(function () {
        $(".textformulario").val("");
        cargarTipoPersonaSelect("textTipoPersona");
    });

    $("[name = btnEditarPersona]").click(function () {
        actualizarPersona();
    });

    $("[name = btnAgregarCredito]").click(function () {
        agregarCredito();
    });

    $("[name = btnCargarCreditos]").click(function () {
        cargarCreditos();
    });

    $("[name = btnEditarCredito]").click(function () {
        editarCredito();
    });

    $("[name = btnGuardarAbono]").click(function () {
        agregarAbono();
    });

    //FUNCION DE BUSCAR PERSONA
    $("[name = btnSeleccionarPersona]").click(function () {
        seleccionarPersona();
    });

    $("[name = btnEncontrar]").click(function () {
        encontrarPersona();
    });

    $("#abonoAutomatico").change(function () {
        if ($(this).is(":checked")) {
            $("[name=textValorAgregarAbono]").attr("readonly", true);
        } else {
            $("[name=textValorAgregarAbono]").removeAttr("readonly");
        }
    });

});