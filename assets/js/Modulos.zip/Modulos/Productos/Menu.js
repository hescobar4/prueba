var modelFilaSeleccione = '<option selected="true" value="">Seleccione</option>';
var modelFilaSelect = '<option value="{0}">{1}</option>';

var cargarLaboratorios = function (nameSelect, labCodAsiganar, labDetalleAsignar) {
    var select = $("[name=" + nameSelect + "]");
    $.ajax({
        url: BASE_URL + "Laboratorios/Menu/cargarLaboratorios",
        type: 'POST',
        data: {
            labCod: labCodAsiganar
        },
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                select.empty();
                if (labCodAsiganar != 0) {
                    select.append('<option selected="true" value="' + labCodAsiganar + '">' + labDetalleAsignar + '</option>');
                } else {
                    select.append(modelFilaSeleccione);
                }
                for (var i = 0; i < data.length; i++) {
                    select.append(modelFilaSelect.format(
                        data[i]['LABCOD'],
                        data[i]['LABDETALLE'],
                    ));
                }
            } else {
                cuerpoTabla.empty();
                notificar(false, 'No se encontró información de Laboratorios');
            }
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {
    });
}

var eliminarProducto = function () {
    var cod = $(this).data("cod");
    bootbox.confirm({
        title: "Confirmaci&oacute;n del Sistema",
        message: "&iquest;Est&aacute; seguro que desea eliminar el registro?",
        buttons: {
            confirm: {
                label: "Si",
                className: "btn-success"
            },
            cancel: {
                label: "No",
                className: "btn-danger"
            }
        },
        callback: function (result) {
            if (result === true) {
                $.ajax({
                    url: BASE_URL + "Productos/Menu/eliminarProducto",
                    type: 'POST',
                    data: {
                        cod: cod
                    },
                    dataType: 'JSON',
                    success: function (r) {
                        notificar(r.data.success, r.data.msg);
                        $("[name=btnCargarProductos]").click();
                        hideLoading();
                    }
                }).fail(function () {
                    notificar(false, 'Error al procesar, por favor intente nuevamente');
                }).always(function () {

                });
            };
        }
    });
}

var modalEditarProducto = function () {
    var cod = $(this).data("cod");
    var codigo = $(this).data("codigo");
    var nombre = $(this).data("nombre");
    var detalle = $(this).data("detalle");
    var labCod = $(this).data("labcod");
    var labDetalle = $(this).data("labdetalle");

    $("[name=codProductoEditar]").val((cod != "") ? cod : "");
    $("[name=textCodigoProductoEditar]").val((codigo != "") ? codigo : "");
    $("[name=textNombreProductoEditar]").val((nombre != "") ? nombre : "");
    $("[name=textDetalleProductoEditar]").val((detalle != "") ? detalle : "");

    cargarLaboratorios("sLabEditar", labCod, labDetalle);

    ejecutarModal('modalEditarProducto');
}

$(document).ready(function () {

    $("[name=btnAgregarProducto]").click(function () {
        var validate = $("[name = formularioAgregarProducto]").formValidation({
            returnData: true
        });
        if (validate.error === true) {
            notificar(false, validate.message);
        } else {
            showLoading();
            $.ajax({
                url: BASE_URL + "Productos/Menu/agregarProductos",
                type: 'POST',
                data: {
                    datos: validate.data
                },
                dataType: 'JSON',
                success: function (r) {
                    notificar(r.data.success, r.data.msg);
                    if (r.data.success) {
                        ocultarModal("modalAgregarProducto");
                        $("[name=btnCargarProductos]").click();
                    }
                    hideLoading();
                }
            }).fail(function () {
                notificar(false, 'Error al procesar, por favor intente nuevamente');
            }).always(function () {

            });
        }
    });

    $("[name=btnCargarProductos]").click(function () {
        var cuerpoTabla = $("[name=cuerpoTablaProductos]");
        var modelFila =
            '<tr>' +
            '<td><span class="icon icon-pencil2 text-primary" title="Editar" style="text-decoration:none; cursor:pointer; font-size:15px;" name="editarProducto" data-cod="{0}" data-codigo="{1}" data-nombre="{2}" data-detalle="{3}" data-labcod="{4}" data-labdetalle="{5}"></span> <span class="icon icon-bin text-danger" title="Eliminar" style="text-decoration:none; cursor:pointer; font-size:15px;" name="eliminarProducto" data-cod="{0}"></span></td>' +
            '                           <td>{6}</td>' +
            '                           <td>{1}</td>' +
            '                           <td>{2}</td>' +
            '                           <td>{3}</td>' +
            '                           <td>{5}</td>' +
            '                   </tr>';
        $.ajax({
            url: BASE_URL + "Productos/Menu/cargarProductos",
            dataType: 'JSON',
            success: function (r) {
                var data = r.data;
                if (data.length > 0) {
                    cuerpoTabla.empty();
                    for (var i = 0; i < data.length; i++) {
                        cuerpoTabla.append(modelFila.format(
                            data[i]['PROCOD'],
                            data[i]['PROCODIGODET'],
                            data[i]['PRONOMBRE'],
                            data[i]['PRODETALLE'],
                            data[i]['LABCOD'],
                            data[i]['LABDETALLE'],
                            i + 1
                        ));
                    }
                    cuerpoTabla.find("[name=eliminarProducto]").on("click", eliminarProducto);
                    cuerpoTabla.find("[name=editarProducto]").on("click", modalEditarProducto);
                } else {
                    cuerpoTabla.empty();
                    notificar(false, 'No se encontró información de Productos');
                }
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {
        });
    });

    $("[name=btnEditaProducto]").click(function () {
        var validate = $("[name = formularioEditarProducto]").formValidation({
            returnData: true
        });
        if (validate.error === true) {
            notificar(false, validate.message);
        } else {
            showLoading();
            $.ajax({
                url: BASE_URL + "Productos/Menu/editarProductos",
                type: 'POST',
                data: {
                    datos: validate.data
                },
                dataType: 'JSON',
                success: function (r) {
                    notificar(r.data.success, r.data.msg);
                    if (r.data.success) {
                        ocultarModal("modalEditarProducto");
                        $("[name=btnCargarProductos]").click();
                    }
                    hideLoading();
                }
            }).fail(function () {
                notificar(false, 'Error al procesar, por favor intente nuevamente');
            }).always(function () {

            });
        }
    });

    $("[name=btnModalAgregarProducto]").click(function () {
        cargarLaboratorios("sLab", 0, "0");
    });
});
