var cargarUsuarios = function () {
    var compUsarios = $("[name=sUsuarioReporteVenta]");
    var model = '<option value="{0}">{2} - {1} - {3}</option>';
    $.ajax({
        url: BASE_URL + "Usuarios/Usuarios/cargarUsuarios",
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                compUsarios.empty();
                compUsarios.append('<option selected="true" value="0">Seleccione</option>');
                for (var i = 0; i < data.length; i++) {
                    compUsarios.append(model.format(
                        data[i]['USUCOD'],
                        data[i]['NOMBRE'],
                        data[i]['USUCEDULA'],
                        data[i]['ESTADOUSUARIO'],
                    ));
                }
            } else {
                sinInformacion();
                compUsarios.empty();
            }
            hideLoading();
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {
    });
}

$(document).ready(function () {
    $("[name=btnGeneraReporteVentas]").click(function () {
        var validate = $("[name=formularioReporteVentasFecha]").formValidation({
            returnData: true
        });
        if (validate.error === true) {
            notificar(false, validate.message);
        } else {
            var tipoReporte = $("[name=validarTipoReporte]").val();
            var codUser = $("[name=sUsuarioReporteVenta]").val();

            if (tipoReporte == 1) {
                window.open(BASE_URL + 'Reportes/Menu/reporteVentasFechaPdf?desde=' + validate.data['textFechaDesdeReporteVenta'] + '&hasta=' + validate.data['textFechaHastaReporteVenta'] + '&user=' + codUser, '_blank');
                return;
            }
            if (tipoReporte == 2) {
                window.open(BASE_URL + 'Reportes/Menu/reporteVentasFechaExcel?desde=' + validate.data['textFechaDesdeReporteVenta'] + '&hasta=' + validate.data['textFechaHastaReporteVenta'], '_blank');
                return;
            }
        }
    });

    $("[name=btnReporteProductos]").click(function () {
        window.open(BASE_URL + 'Reportes/Menu/reporteProductos', '_blank');
        return;
    });

    $("[name=validarReporteVentasPdf]").click(function () {
        $("[name=validarTipoReporte]").val(1);
        cargarUsuarios();
    });

    $("[name=validarReporteVentasExcel]").click(function () {
        $("[name=validarTipoReporte]").val(2);
    });
});