var cargarLaboratorios = function () {
    var cuerpoTabla = $("[name=cuerpoTablaLab]");
    var modelFila =
        '<tr>' +
        '<td><span class="icon icon-pencil2 text-primary" title="Editar" style="text-decoration:none; cursor:pointer; font-size:15px;" name="editarLab" data-cod="{0}" data-detalle="{1}" data-estado="{2}"></span> <span class="icon icon-bin text-danger" title="Eliminar" style="text-decoration:none; cursor:pointer; font-size:15px;" name="eliminarLab" data-cod="{0}"></span></td>' +
        '                           <td>{3}</td>' +
        '                           <td>{1}</td>' +
        '                   </tr>';
    $.ajax({
        url: BASE_URL + "Laboratorios/Menu/cargarLaboratorios",
        dataType: 'JSON',
        success: function (r) {
            var data = r.data;
            if (data.length > 0) {
                cuerpoTabla.empty();
                for (var i = 0; i < data.length; i++) {
                    cuerpoTabla.append(modelFila.format(
                        data[i]['LABCOD'],
                        data[i]['LABDETALLE'],
                        data[i]['LABESTADO'],
                        i + 1
                    ));
                }
                cuerpoTabla.find("[name=eliminarLab]").on("click", eliminarLab);
                cuerpoTabla.find("[name=editarLab]").on("click", modalEditarLab);
            } else {
                cuerpoTabla.empty();
                notificar(false, 'No se encontró información de Laboratorios');
            }
        }
    }).fail(function () {
        notificar(false, 'Error al procesar, por favor intente nuevamente');
    }).always(function () {
    });
}

var eliminarLab = function () {
    var cod = $(this).data("cod");
    bootbox.confirm({
        title: "Confirmaci&oacute;n del Sistema",
        message: "&iquest;Est&aacute; seguro que desea eliminar el registro?",
        buttons: {
            confirm: {
                label: "Si",
                className: "btn-success"
            },
            cancel: {
                label: "No",
                className: "btn-danger"
            }
        },
        callback: function (result) {
            if (result === true) {
                $.ajax({
                    url: BASE_URL + "Laboratorios/Menu/eliminarLab",
                    type: 'POST',
                    data: {
                        cod: cod
                    },
                    dataType: 'JSON',
                    success: function (r) {
                        notificar(r.data.success, r.data.msg);
                        cargarLaboratorios();
                        hideLoading();
                    }
                }).fail(function () {
                    notificar(false, 'Error al procesar, por favor intente nuevamente');
                }).always(function () {

                });
            };
        }
    });
}

var modalEditarLab = function () {
    $("[name=textDetalleLabEditar]").val(($(this).data("detalle")!="")? $(this).data("detalle"):"");
    $("[name=textLabCod]").val(($(this).data("cod")!="")? $(this).data("cod"):"");
    ejecutarModal("modalEditarLab");
}

var agregarLab = function () {
    var validate = $("[name = formularioAgregarLab]").formValidation({
        returnData: true
    });
    if (validate.error === true) {
        notificar(false, validate.message);
    } else {
        showLoading();
        $.ajax({
            url: BASE_URL + "Laboratorios/Menu/agregarLab",
            type: 'POST',
            data: {
                datos: validate.data
            },
            dataType: 'JSON',
            success: function (r) {
                notificar(r.data.success, r.data.msg);
                if (r.data.success) {
                    ocultarModal("modalAgregarLab");
                    cargarLaboratorios();
                }
                hideLoading();
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {

        });
    }
}

var editarLab = function(){
    var validate = $("[name = formularioEditarLab]").formValidation({
        returnData: true
    });
    if (validate.error === true) {
        notificar(false, validate.message);
    } else {
        showLoading();
        $.ajax({
            url: BASE_URL + "Laboratorios/Menu/editarLab",
            type: 'POST',
            data: {
                datos: validate.data
            },
            dataType: 'JSON',
            success: function (r) {
                notificar(r.data.success, r.data.msg);
                if (r.data.success) {
                    ocultarModal("modalEditarLab");
                    cargarLaboratorios();
                }
                hideLoading();
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {

        });
    }
}

$(document).ready(function () {
    $("[name=cargarLabs]").click(function () {
        cargarLaboratorios();
    });

    $("[name=btnAgregarLab]").click(function () {
        agregarLab();
    });

    $("[name=btnLabEditar]").click(function () {
        editarLab();
    });

});