$(document).ready(function () {
    $("[name=btnCargarInventario]").click(function () {
        var cuerpoTabla = $("[name=cuerpoTablaInventario]");
        var modelFila =
            '<tr>' +
            '<td><span class="icon icon-eye text-success" title="Entradas" style="text-decoration:none; cursor:pointer; font-size:15px;" name="movimientos" data-codinv="{0}" data-codigo="{2}" data-nombre="{4}" data-detalle="{3}" data-hentradas="{11}" data-hsalidas="{12}"></span></td>' +
            '                           <td>{9}</td>' +
            '                           <td>{2}</td>' +
            '                           <td>{4}</td>' +
            '                           <td>{3}</td>' +
            '                           <td>{13}</td>' +
            '                           <td>{5}</td>' +
            '                           <td>{6}</td>' +
            '                           <td>{11}</td>' +
            '                           <td>{12}</td>' +
            '                           <td>{7}</td>' +
            '                           <td>{10}</td>' +
            '                           <td>{8}</td>' +
            '                   </tr>';

        showLoading();
        $.ajax({
            url: BASE_URL + "Inventario/Menu/cargarInventario",
            dataType: 'JSON',
            success: function (r) {
                var data = r.data;
                if (data.length > 0) {
                    cuerpoTabla.empty();
                    for (var i = 0; i < data.length; i++) {
                        cuerpoTabla.append(modelFila.format(
                            data[i]['INVCOD'],
                            data[i]['PROCOD'],
                            data[i]['PROCODIGODET'],
                            data[i]['PRODETALLE'],
                            data[i]['PRONOMBRE'],
                            data[i]['sumaTotalEntradas'],
                            data[i]['sumaTotalSalidas'],
                            data[i]['sumaTotalStock'],
                            data[i]['sumaValorStock'],
                            i + 1,
                            data[i]['utilidad'],
                            data[i]['INVENTRADAS'],
                            data[i]['INVSALIDAS'],
                            data[i]['LABDETALLE']
                        ));
                    }
                    cuerpoTabla.find("[name=movimientos]").on("click", modalMovimientos);
                } else {
                    cuerpoTabla.empty();
                    notificar(false, 'No se encontró información de Productos');
                }
                hideLoading();
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {

        });
    });

    var modalMovimientos = function () {
        var codInv = $(this).data("codinv");
        var codigo = $(this).data("codigo");
        var nombre = $(this).data("nombre");
        var detalle = $(this).data("detalle");
        var entradas = $(this).data("hentradas");
        var salidas = $(this).data("hsalidas");
        $("[name=textInvCod]").val((codInv != "") ? codInv : "");
        $("[name=textCodigoProductoMov]").val((codigo != "") ? codigo : "");
        $("[name=textNombreProductoMov]").val((nombre != "") ? nombre : "");
        $("[name=textDetalleProductoMov]").val((detalle != "") ? detalle : "");
        $("[name=textEntradasProductoMov]").val((entradas != "") ? entradas : 0);
        $("[name=textSalidasProductoMov]").val((salidas != "") ? salidas : 0);
        $("[name=cuerpoTablaEntradas]").empty();
        ejecutarModal("modalMovimientos");
    }

    $("[name=btnAgregarEntrada]").click(function () {
        var validate = $("[name = formularioAgregarEntrada]").formValidation({
            returnData: true
        });
        if (validate.error === true) {
            notificar(false, validate.message);
        } else {
            showLoading();
            $.ajax({
                url: BASE_URL + "Inventario/Menu/agregarEntrada",
                type: 'POST',
                data: {
                    datos: validate.data
                },
                dataType: 'JSON',
                success: function (r) {
                    notificar(r.data.success, r.data.msg);
                    if (r.data.success) {
                        ocultarModal("modalAgregarEntrada");
                        cargarEntradas(1);
                        $("[name=btnCargarInventario]").click();
                    }
                    hideLoading();
                }
            }).fail(function () {
                notificar(false, 'Error al procesar, por favor intente nuevamente');
            }).always(function () {

            });
        }
    });

    $("[name=btnCargarEntradasActivas]").click(function () {
        cargarEntradas(1);
    });
    $("[name=btnCargarEntradasHistorial]").click(function () {
        cargarEntradas(2);
    });


    var cargarEntradas = function (parametro) {
        var cuerpoTabla = $("[name=cuerpoTablaEntradas]");
        var codInv = $("[name=textInvCod]").val();
        var modelFila =
            '<tr>' +
            '<td><span class="icon icon-bin text-danger" title="Eliminar" style="text-decoration:none; cursor:pointer; font-size:15px;" name="eliminarEntrada" data-codentrada="{0}"></span> <span class="icon icon-pencil2 text-primary" title="Editar" style="text-decoration:none; cursor:pointer; font-size:15px;" name="editarEntrada" data-codentrada="{0}" data-cantidadsal="{2}" data-cantidadent="{1}" data-valorcompra="{4}"></span></td>' +
            '                           <td>{9}</td>' +
            '                           <td>{1}</td>' +
            '                           <td>{2}</td>' +
            '                           <td>{3}</td>' +
            '                           <td>{4}</td>' +
            '                           <td>{5}</td>' +
            '                           <td>{6}</td>' +
            '                           <td>{10}</td>' +
            '                           <td>{7}</td>' +
            '                           <td>{8}</td>' +
            '                   </tr>';
        showLoading();
        $.ajax({
            url: BASE_URL + "Inventario/Menu/cargarEntradas",
            type: 'POST',
            data: {
                codInv: codInv,
                parametro: parametro
            },
            dataType: 'JSON',
            success: function (r) {
                var data = r.data.entradas;
                var datosGeneral = r.data.datosSE;
                if (data.length > 0) {
                    cuerpoTabla.empty();
                    for (var i = 0; i < data.length; i++) {
                        cuerpoTabla.append(modelFila.format(
                            data[i]['INVDETCOD'],
                            data[i]['INVDETCANTIDADENT'],
                            data[i]['INVDETCANTIDADSAL'],
                            data[i]['CANTIDADSTOCK'],
                            data[i]['INVDETVALORCOMPRA'],
                            data[i]['INVDETVALORUNI'],
                            data[i]['TOTALCOSTO'],
                            data[i]['TOTALVENTA'],
                            data[i]['INVDETFECHA'],
                            i + 1,
                            data[i]['UTILIDAD']
                        ));
                    }
                    cuerpoTabla.find("[name=eliminarEntrada]").on("click", eliminarEntrada);
                    cuerpoTabla.find("[name=editarEntrada]").on("click", modalEditarEntrada);

                    $("[name=textEntradasProductoMov]").val((datosGeneral[0]['INVENTRADAS'] != "") ? datosGeneral[0]['INVENTRADAS'] : 0);
                    $("[name=textSalidasProductoMov]").val((datosGeneral[0]['INVSALIDAS'] != "") ? datosGeneral[0]['INVSALIDAS'] : 0);
                } else {
                    cuerpoTabla.empty();
                    notificar(false, 'No se encontró información de Entradas');
                }
                hideLoading();
            }
        }).fail(function () {
            notificar(false, 'Error al procesar, por favor intente nuevamente');
        }).always(function () {

        });
    }

    var eliminarEntrada = function () {
        var codEntrada = $(this).data("codentrada");
        bootbox.confirm({
            title: "Confirmaci&oacute;n del Sistema",
            message: "&iquest;Est&aacute; seguro que desea eliminar el registro?",
            buttons: {
                confirm: {
                    label: "Si",
                    className: "btn-success"
                },
                cancel: {
                    label: "No",
                    className: "btn-danger"
                }
            },
            callback: function (result) {
                if (result === true) {
                    $.ajax({
                        url: BASE_URL + "Inventario/Menu/eliminarEntrada",
                        type: 'POST',
                        data: {
                            codEntrada: codEntrada
                        },
                        dataType: 'JSON',
                        success: function (r) {
                            notificar(r.data.success, r.data.msg);
                            cargarEntradas(1);
                            $("[name=btnCargarInventario]").click();
                            hideLoading();
                        }
                    }).fail(function () {
                        notificar(false, 'Error al procesar, por favor intente nuevamente');
                    }).always(function () {

                    });
                };
            }
        });
    }

    var modalEditarEntrada = function () {
        var codEntrada = $(this).data("codentrada");
        var cantidadEntrada = $(this).data("cantidadent");
        var cantidadSalida = $(this).data("cantidadsal");
        var valorCompra = $(this).data("valorcompra");
        $("[name=codEntradaEditar]").val((codEntrada != "") ? codEntrada : "");
        $("[name=textCantidadEntradaEditar]").val((cantidadEntrada != "") ? cantidadEntrada : "");
        $("[name=textValorCompraEntradaEditar]").val((valorCompra != "") ? valorCompra.toString().replace(/[.]/g, "") : "");
        $("[name=textCantidadSalidaValidar]").val((cantidadSalida != "") ? cantidadSalida : "");
        ejecutarModal("modalEditarEntrada");
    }

    $("[name=btnEditarEntrada]").click(function () {
        var validate = $("[name = formularioEditarEntrada]").formValidation({
            returnData: true
        });
        if (validate.error === true) {
            notificar(false, validate.message);
        } else {
            var cantidadNueva = $("[name=textCantidadEntradaEditar]").val();
            var cantidadSalida = $("[name=textCantidadSalidaValidar]").val();
            if (parseInt(cantidadNueva) < parseInt(cantidadSalida)) {
                notificar(false, "No se puede editar, la cantidad debe ser igual o mayor a las salidas registradas.");
                return;
            }
            showLoading();
            $.ajax({
                url: BASE_URL + "Inventario/Menu/editarEntrada",
                type: 'POST',
                data: {
                    datos: validate.data
                },
                dataType: 'JSON',
                success: function (r) {
                    notificar(r.data.success, r.data.msg);
                    if (r.data.success) {
                        ocultarModal("modalEditarEntrada");
                        cargarEntradas(1);
                        $("[name=btnCargarInventario]").click();
                    }
                    hideLoading();
                }
            }).fail(function () {
                notificar(false, 'Error al procesar, por favor intente nuevamente');
            }).always(function () {

            });
        }

    });
});